<template>
  <div class="add container">
    <h1 class="page-header">添加用户</h1>
    <form v-on:submit="addCustomer">
    	<div class="well">
    		<h4>用户信息</h4>
        <!-- 
          phone/email/education
          graduationschool/profession 
        -->
    		<div class="form-group">
    			<label>姓名</label>
    			<input type="text" class="form-control" placeholder="name" v-model="customer.name">
    		</div>
    		<div class="form-group">
    			<label>个人简介</label>
    			<textarea class="form-control" rows="10" v-model="customer.profile"></textarea>
    		</div>
    		<button type="submit" class="btn btn-primary">添加</button>
    	</div>
    </form>
  </div>
</template>

<script>
export default {
  name: 'add',
  data () {
    return {
      customer:{},
    }
  },
  methods:{
  	addCustomer(e){
  		// console.log(123);
  		if (!this.customer.name || !this.customer.phone || !this.customer.email) {
  			// console.log("请添加对应的信息!");
  		}else{
  			let newCustomer = {
  				name:this.customer.name
  			}
  			this.$http.post("http://localhost:3000/users",newCustomer)
  				.then(function(response){
  					this.$router.push(
              {path:"/",query:{alert:"用户信息添加成功"}}
            );
  				})
  			e.preventDefault();
  		}
  		e.preventDefault();
  	}
  },
  components:{
  	Alert
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
